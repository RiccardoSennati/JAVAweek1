package Ex1;

public class Livello {

	public static Livello OPERAIO ;
	public static Livello IMPIEGATO ;
	public static Livello QUADRO ;
	public static Livello DIRIGENTE ;

}
