package Ex1;

public class Dipartimento {

	public static Dipartimento PRODUZIONE;
	public static Dipartimento AMMINISTRAZIONE;
	public static Dipartimento VENDITE;

}
