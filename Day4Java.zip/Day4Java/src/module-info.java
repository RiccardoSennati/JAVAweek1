/**
 * 
 */
/**
 * @author riccardosennati
 *
 */
module Day4Java {
}