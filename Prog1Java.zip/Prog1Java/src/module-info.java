/**
 * 
 */
/**
 * @author riccardosennati
 *
 */
module Prog1Java {
}