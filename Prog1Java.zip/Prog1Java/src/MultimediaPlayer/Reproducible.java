package MultimediaPlayer;

public interface Reproducible {

    void play();
    int downVolume();
    public int increasesVolume();
}
