package MultimediaPlayer;

public abstract class MultimediaElement {

	static int def = 5;
    // Properties
	private String title;

    //Constructor
	public MultimediaElement(String title) {
		this.title = title;
	}

	
	public String getTitle() {
		return title;
	}
	
	protected void setTitle(String title) {
		this.title = title;
	}
	
    //Method
	abstract public void run();
	
}
