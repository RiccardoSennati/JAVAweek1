package MultimediaPlayer;

import java.util.Scanner;

public class MediaPlayer {
	
	static String title, type, n;
	static int luminosita;
	static Scanner in = new Scanner(System.in);

    //Main
	public static void main(String[] args) {
		MultimediaElement[] arr = new MultimediaElement[5];

		System.out.printf("Music player is on, insert 5 items:%n");

		for (int i = 0; i < arr.length; i++) {
			System.out.printf(
					"%n------------------------------------------------------%nElement-%d%n %nPlease choose the content:%n- Image (Type 'i')%n- Registration (Type 'r')%n- Video (Type 'v')%n------------------------------------------------------%n",
					i + 1);
			type = in.nextLine();
			while (!(type.equals("i") || type.equals("r") || type.equals("v"))) {
				System.out.printf("%nInvalid, try with a command%n");
				type = in.nextLine();
			}
			;
			switch (type) {
			case "i":
				System.out.println("You choose image, now choose the title: ");
				title = in.nextLine();
				arr[i] = new Image(title);
				break;
			case "r":
				System.out.println("You choose Registartion, now choose the title: ");
				title = in.nextLine();
				arr[i] = new Registration(title);
				break;
			case "v":
				System.out.println("You choose video, now choose the title: ");
				title = in.nextLine();
				arr[i] = new Video(title);
				break;
			default:
				System.out.println("Invalid");
			}
		}
		System.out.printf("%n5 Successfully created items%n--------------------%n%n--------------------%n");
		do {
			System.out.printf("%nPlease select the item to run (1,2,3), or stop  (0)%n");
			n = in.nextLine();
			switch (n) {
			case "1":
				arr[0].run();
				break;
			case "2":
				arr[1].run();
				break;
			case "3":
				arr[2].run();
				break;
			case "4":
				arr[3].run();
				break;
			case "5":
				arr[4].run();
				break;
			case "0":
				System.out.println("App finished");;
				break;
			default:
				System.out.printf("%nInvalid, try with a command%n");
			}
		} while (!(n.equals("0")));
		
	}

}

