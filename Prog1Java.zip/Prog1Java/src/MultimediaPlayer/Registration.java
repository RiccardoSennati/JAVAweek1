package MultimediaPlayer;

public class Registration extends MultimediaElement implements Reproducible{
	
    //Properties
	
	private int duration;
	private int volume;
	
    //Constructors Overload
	
	public Registration(String title) {
		super(title);
		this.duration = MultimediaElement.def;
		this.volume = MultimediaElement.def;
	}
	public Registration(String title, int duration, int volume) {
		super(title);
		this.duration = duration;
		this.volume = volume;
	}
    //Getters
	public int getDuration() {
		return duration;
	}
	public int getVolume() {
		return volume;
	}
    //Setters 
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public void setVolume(int volume) {
		this.volume = volume;
	}
    //Methods
	public int downVolume() {
		return this.volume--;
	}
	public int increasesVolume() {
		return this.volume--;
	}
	public void run() {
		play();
	}
	public void play() {
		System.out.println("Reg, " + getTitle() + " " + "!".repeat(this.volume));
	}
	
}
