/**
 * 
 */
/**
 * @author riccardosennati
 *
 */
module Day3Java {
}